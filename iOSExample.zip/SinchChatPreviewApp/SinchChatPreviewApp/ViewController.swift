//
//  ViewController.swift
//  SinchChatPreviewApp
//
//  Created by Sinch on 14/02/2022.
//

import UIKit
import SinchChatSDK

final class ViewController: UIViewController {
    
    private let sinchSDKUserSecret = "{{ secret }}"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // anonymous session will generate random User ID.
        /*
         email: aldawaa@gmail.com
         user-id: 13-13
    
         */
    
        let internalUserID = "123-123-123"
        let signedUser = internalUserID.hmac(algorithm: .SHA512, key: sinchSDKUserSecret)
        
        SinchChatSDK.shared.setIdentity(
            with: .init(clientID: clientID,
                        projectID: projectID,
                        region: .EU1),
            identity: .selfSigned(userId: internalUserID, secret: signedUser)) { result in
            switch result {
            case .success:
                DispatchQueue.main.async {
                    self.showChat()
                }
            case .failure(let error):
                print(error)
            }
        }
    }
    
    func showChat() {
        do {
            var uiConfig = SinchSDKConfig.UIConfig.defaultValue
            uiConfig.navigationBarText = "Random text"
            let viewControler = try SinchChatSDK.shared.chat.getChatViewController(navigationController: nil, uiConfig: uiConfig, localizationConfig: nil)
                        
            present(viewControler, animated: true, completion: nil)
        } catch {
            print(error)
        }
        
        
    }

}

