//
//  ViewController.swift
//  SinchChatPreviewApp
//
//  Created by Sinch on 14/02/2022.
//

import UIKit
import SinchChatSDK

final class ViewController: UIViewController {
    
    private let sinchSDKUserSecret = "{{ secret }}"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // anonymous session will generate random User ID.
        /*
         email: aldawaa@gmail.com
         user-id: 13-13
    
         */
    
        let internalUserID = "123-123-123"
    
        
        SinchChatSDK.shared.setIdentity(
            with: .init(clientID: clientID,
                        projectID: projectID,
                        configID: "",
                        region: .EU1),
            identity: .anonymous) { result in
            switch result {
            case .success:
                DispatchQueue.main.async {
                    self.showChat()
                }
            case .failure(let error):
                print(error)
            }
        }
    }
    
    func showChat() {
        do {
            var uiConfig = SinchSDKConfig.UIConfig.defaultValue
            let viewControler = try SinchChatSDK.shared.chat.getChatViewController(uiConfig: uiConfig, localizationConfig: .defaultValue)
                        
            present(viewControler, animated: true, completion: nil)
        } catch {
            print(error)
        }
        
        
    }

}

