import SwiftUI
import SinchChatSDK

struct ChatView: UIViewControllerRepresentable {
  
    var title: String?
    var options: GetChatViewControllerOptions

    typealias UIViewControllerType = UINavigationController
    
    func makeUIViewController(context: Context) -> UINavigationController {
        do {

            let uiConfig = SinchSDKConfig.UIConfig.defaultValue
         
            var localizationConfig = SinchSDKConfig.LocalizationConfig.defaultValue
            if let title = title {
                localizationConfig.navigationBarText = title
            }
            let viewControler = try SinchChatSDK.shared.chat.getChatViewController(uiConfig: uiConfig,
                                                                                   localizationConfig: localizationConfig,
                                                                          options: options)
            let navigationController = UINavigationController(rootViewController: viewControler)

            return navigationController
        } catch {
            print(error)
        }
        return UINavigationController(rootViewController: UIViewController())
    }

    func updateUIViewController(_ uiViewController: UINavigationController, context: Context) {
        // Updates the state of the specified view controller with new information from SwiftUI.
    }
}
 

struct ChatView_Previews: PreviewProvider {
    static var previews: some View {
        ChatView(options: .init(metadata: []))
    }
}

