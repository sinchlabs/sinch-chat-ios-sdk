import SwiftUI
import SinchChatSDK


// Sinch Dashboard Credentials.
let PROJECT_ID = "{{ PROJECT_ID }}"
let CLIENT_ID = "{{ CLIENT_ID }}"
let CONFIG_ID = "{{ CONFIG_IF }}"

let SECRET = "{{ SECRET }}"

// Company Backend
let ORDER_ID_FROM_BACKEND = "order_1"

let exampleCustomerID = "customer_1"
let exampleDriverID = "driver_1"

struct ContentView: View {
    @State var isStarting: Bool = false
    @State var isShowingChat = false
    @State var chatTitle: String = "Chat"
    @State var startWithOptions: GetChatViewControllerOptions? = nil
    
    var body: some View {
        VStack {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundStyle(.tint)
            Text("Hello, Delivery App demo!")
            
            Button(action: {
                start(.driver(id: exampleDriverID))
            }) {
                Text(isStarting ? "Loading..." : "Start Driver")
            }
            .disabled(isStarting)
            .buttonStyle(.borderedProminent)
            .padding(.all)
            
            Button(action: {
                start(.customer(id: exampleCustomerID))
            }) {
                Text(isStarting ? "Loading..." : "Start Customer")
            }
            .disabled(isStarting)
            .buttonStyle(.borderedProminent)
            .padding(.all)
            
        }
        .padding()
        .fullScreenCover(isPresented: $isShowingChat, onDismiss: {
            isShowingChat = false
            SinchChatSDK.shared.removeIdentity { result in
                debugPrint("REMOVED IDENTITY")
            }
        }) {
            ChatView(title: chatTitle, options: startWithOptions ?? GetChatViewControllerOptions(metadata: []) ).ignoresSafeArea()
        }
    }
    
    func start(_ mode: Mode) {
        isStarting = true
        switch mode {
        case .customer(let id):
            getChatOptionsForCustomer(customerID: id, orderID: ORDER_ID_FROM_BACKEND) { options in
                chatTitle = "Customer"
                startWithOptions = options
                isShowingChat = true
                isStarting = false
            }
        case .driver(let id):
            getChatOptionsForDriver(driverID: id, orderID: ORDER_ID_FROM_BACKEND) { options in
                chatTitle = "Driver"
                startWithOptions = options
                isShowingChat = true
                isStarting = false
            }
        }
    }
}

enum Mode {
    case driver(id: String)
    case customer(id: String)
}

#Preview {
    ContentView()
}

func loginToSDKUsing(_ userID: String, completion: @escaping (Bool) -> Void) {
    SinchChatSDK.shared.setIdentity(
        with: .init(
            clientID: CLIENT_ID,
            projectID: PROJECT_ID,
            configID: CONFIG_ID,
            region: .EU1
        ),
        identity: .selfSigned(
            userId: userID,
            secret: userID.hmac(algorithm: .SHA512, key: SECRET)
        )
    ) { result in
        switch result {
        case .success:
            completion(true)
        case .failure(let err):
            print("error", err)
            completion(false)
        }
    }
}

func getChatOptionsForDriver(driverID: String, orderID: String, completion: @escaping (_ options: GetChatViewControllerOptions?) -> Void) {
    loginToSDKUsing(driverID) { isSuccess in
        let options = isSuccess ? prepareMetadataForChat(
            orderID: orderID,
            toWhoIWantToCallAndSendMessageID: "",
            myDisplayName: nil,
            myPictureUrl: nil
        ) : nil
        completion(options)
    }
}

func getChatOptionsForCustomer(customerID: String, orderID: String, completion: @escaping (_ options: GetChatViewControllerOptions?) -> Void) {
    loginToSDKUsing(customerID) { isSuccess in
        let options = isSuccess ? prepareMetadataForChat(
            orderID: orderID,
            toWhoIWantToCallAndSendMessageID: "",
            myDisplayName: nil,
            myPictureUrl: nil
        ) : nil
        completion(options)
    }
}

func prepareMetadataForChat(
    orderID: String,
    toWhoIWantToCallAndSendMessageID: String,
    myDisplayName: String?,
    myPictureUrl: URL?) -> GetChatViewControllerOptions {
    
    var metadata: SinchMetadataArray = [
        SinchMetadataCustom(key: "addressee", value: toWhoIWantToCallAndSendMessageID, mode: .withEachMessage)
    ]
    
    if let displayName = myDisplayName {
        metadata.append(
            SinchMetadataCustom(key: "senderDisplayName", value: displayName, mode: .withEachMessage)
        )
    }
    
    if let pictureUrl = myPictureUrl {
        metadata.append(
            SinchMetadataCustom(key: "senderPictureUrl", value: pictureUrl.absoluteString, mode: .withEachMessage)
        )
    }
    
    let options = GetChatViewControllerOptions(topicID: orderID, metadata: metadata)
        
    return options
}

